import tensorflow as tf
from keras.utils import image_dataset_from_directory
from tensorflow.keras import layers
from config import train_directory, test_directory, image_size, batch_size, validation_split

def get_transfer_datasets():
    """
    Load datasets for transfer learning task.
    Modify this function to load your chosen two-class dataset from Kaggle
    (e.g., dog vs cat, fresh vs rotten fruit, etc.)

    Returns:
        Tuple of (train_dataset, validation_dataset, test_dataset)
    """
    from keras.utils import image_dataset_from_directory
    from config import batch_size, image_size, validation_split

    # Define directories for your transfer learning dataset
    transfer_train_dir = 'kaggle/train'  # Update with your dataset path
    transfer_test_dir = 'kaggle/test'    # Update with your dataset path

    print('Loading transfer learning datasets:')
    print('train dataset:')
    train_dataset, validation_dataset = image_dataset_from_directory(
        transfer_train_dir,
        label_mode='categorical',
        color_mode='rgb',
        batch_size=batch_size,
        image_size=image_size,  # Keep same image size for transfer learning
        validation_split=validation_split,
        subset="both",
        seed=47
    )
    
    print('test dataset:')
    test_dataset = image_dataset_from_directory(
        transfer_test_dir,
        label_mode='categorical',
        color_mode='rgb',
        batch_size=batch_size,
        image_size=image_size,
        shuffle=False
    )
    
    return train_dataset, validation_dataset, test_dataset


def _split_data(train_directory, test_directory, batch_size, validation_split):
    print('train dataset:')
    raw_train_dataset, raw_val_dataset = image_dataset_from_directory(
        train_directory,
        label_mode='categorical',
        color_mode='rgb',
        batch_size=batch_size,
        image_size=image_size,
        validation_split=validation_split,
        subset="both",
        seed=47
    )

    # Data Augmentation pipeline (only applied to training set)
    # Adjust or add transformations as you see fit
    data_augmentation = tf.keras.Sequential([
        layers.RandomFlip("horizontal"),     # random left-right flips
        layers.RandomRotation(0.1),          # random rotation
        layers.RandomZoom(0.1),              # random zoom
    ])

    # Augment training dataset
    train_dataset = (
        raw_train_dataset
        .map(lambda x, y: (data_augmentation(x), y), num_parallel_calls=tf.data.AUTOTUNE)
        .cache()
        .prefetch(buffer_size=tf.data.AUTOTUNE)
    )
    # Validation dataset (no augmentation)
    validation_dataset = raw_val_dataset.cache().prefetch(buffer_size=tf.data.AUTOTUNE)
    
    print('test dataset:')
    test_dataset = image_dataset_from_directory(
        test_directory,
        label_mode='categorical',
        color_mode='rgb',
        batch_size=batch_size,
        image_size=image_size,
        shuffle=False
    )
    test_dataset = test_dataset.cache().prefetch(buffer_size=tf.data.AUTOTUNE)

    return train_dataset, validation_dataset, test_dataset


def get_datasets():
    train_dataset, validation_dataset, test_dataset = \
        _split_data(train_directory, test_directory, batch_size, validation_split)
    return train_dataset, validation_dataset, test_dataset
