"""
Calibration script with enhanced realtime feature sensitivity.
This version extracts features from a more spatially sensitive layer,
computes differences from a neutral baseline, and fixes layer index errors.
"""

import os
import numpy as np
import cv2
import tensorflow as tf
from tensorflow.keras.models import load_model
from config import categories, image_size

def process_frame(frame):
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    width, height = frame.shape
    size = min(width, height)
    pad = int((width - size) / 2), int((height - size) / 2)
    frame = frame[pad[0]:pad[0] + size, pad[1]:pad[1] + size]
    return frame

def access_webcam(feature_model=None, baseline_features=None):
    """
    Opens the webcam and continuously displays the processed frame.
    If a feature_model is provided, computes features for each frame.
    If baseline_features is provided, displays the difference (ΔFeatures)
    between the current feature vector and the baseline.
    Press Enter in the webcam window to capture the current frame and features.
    """
    cv2.namedWindow("Calibration")
    vc = cv2.VideoCapture(0)
    if vc.isOpened():
        rval, frame = vc.read()
        frame = process_frame(frame)
    else:
        print("Webcam not accessible.")
        return None, None

    captured_features = None
    while rval:
        display_frame = frame.copy()
        if feature_model is not None:
            # Prepare frame for prediction
            img_resized = cv2.resize(frame, image_size)
            # Convert grayscale to 3-channel image
            img_rgb = np.stack((img_resized,)*3, axis=-1)
            img_normalized = img_rgb / 255.0
            img_batch = np.expand_dims(img_normalized, axis=0)
            # Get feature vector
            pred_features = feature_model.predict(img_batch, verbose=0)
            # Flatten if necessary
            if len(pred_features[0].shape) > 1:
                pred_features = pred_features.reshape(pred_features.shape[0], -1)[0]
            else:
                pred_features = pred_features[0]
            # If baseline is provided, compute the difference
            if baseline_features is not None:
                diff_features = pred_features - baseline_features
            else:
                diff_features = pred_features
            captured_features = diff_features
            # Overlay first few feature differences with higher precision
            feature_text = "Features: " + ", ".join(f"{val:.3f} \n" for val in diff_features[:5])
            cv2.putText(display_frame, feature_text, (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

        cv2.imshow("Calibration", display_frame)
        rval, frame = vc.read()
        if rval:
            frame = process_frame(frame)
        key = cv2.waitKey(20)
        if key == 13:  # Enter key to capture
            break

    vc.release()
    cv2.destroyWindow("Calibration")
    return frame, captured_features

def main():
    calibration_file = 'user_calibration.npz'
    if os.path.exists(calibration_file):
        recalibrate = input("Calibration data already exists. Do you want to recalibrate? (y/n): ")
        if recalibrate.lower() != 'y':
            print("Using existing calibration data. You can now start the game.")
            return

    print("\n==== EXPRESSION CALIBRATION ====")
    print("Let's calibrate the system to your facial expressions.")
    print("We'll capture reference images for each expression.")
    print("IMPORTANT: Make very distinct expressions for each emotion:")
    print(" - NEUTRAL: Relaxed face, no smile, lips closed")
    print(" - HAPPY: Big smile, show teeth if possible")
    print(" - SURPRISE: Open mouth, raised eyebrows")

    reference_features = {}
    model_path = 'results/basic_model_15_epochs_timestamp_1740024064.keras'
    model = load_model(model_path)
    
    # Determine the available layers and select a valid feature layer index.
    total_layers = len(model.layers)
    preferred_index = 14  # Preferred index based on expected architecture
    if total_layers > preferred_index:
        feature_layer_index = preferred_index
    else:
        # Fallback: use the second-to-last layer if the preferred index isn't available.
        feature_layer_index = total_layers - 2

    print(f"Using feature layer index: {feature_layer_index} (Total layers: {total_layers})")
    
    feature_model = tf.keras.Model(inputs=model.input, outputs=model.layers[feature_layer_index].output)
    baseline_features = None  # Will store the neutral expression's features

    for emotion_idx, emotion_name in enumerate(categories):
        input(f"\nPrepare to show your {emotion_name.upper()} expression and press Enter...")
        print(f"When ready, press Enter in the webcam window to capture your {emotion_name} expression.")
        
        # For non-neutral expressions, pass the neutral baseline to highlight subtle differences.
        if emotion_name.lower() == 'neutral':
            print("Capturing neutral baseline...")
            img, features = access_webcam(feature_model, baseline_features=None)
            if features is not None:
                baseline_features = features  # Save neutral features for later comparisons
        else:
            img, features = access_webcam(feature_model, baseline_features=baseline_features)
        
        if img is None:
            print("Failed to capture image from webcam. Please check your camera.")
            return

        # Process the captured image to be consistent with training input
        img_resized = cv2.resize(img, image_size)
        img_rgb = np.stack((img_resized,)*3, axis=-1)
        img_normalized = img_rgb / 255.0
        img_batch = np.expand_dims(img_normalized, axis=0)
        # Recalculate features on the captured image using the chosen layer
        recalculated_features = feature_model.predict(img_batch, verbose=0)
        if len(recalculated_features[0].shape) > 1:
            recalculated_features = recalculated_features.reshape(recalculated_features.shape[0], -1)[0]
        else:
            recalculated_features = recalculated_features[0]

        reference_features[f'emotion_{emotion_idx}'] = recalculated_features
        print(f"{emotion_name.capitalize()} expression captured!")

    # Save calibration data
    np.savez(calibration_file, **reference_features)
    print("\nCalibration complete! You can now start the game with your calibrated expressions.")

if __name__ == "__main__":
    main()
