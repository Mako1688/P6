from preprocess import get_transfer_datasets
from models.transfered_model import TransferedModel
from models.random_model import RandomModel
from config import image_size, categories
import matplotlib.pyplot as plt
import time

# Define input shape and update categories count for the transfer task
input_shape = (image_size[0], image_size[1], 3)
categories_count = 7  # Updated to match the 7 classes in your dataset

# Dictionary of models to compare
models = {
    'transfer_learning': TransferedModel,
    'random_initialization': RandomModel,
}

def plot_history_diff(history_transfer, history_random):
    # Extract validation accuracy for both models
    val_acc_transfer = history_transfer.history['val_accuracy']
    val_acc_random = history_random.history['val_accuracy']
    
    epochs = range(1, len(val_acc_transfer) + 1)
    
    plt.figure(figsize=(10, 6))
    plt.plot(epochs, val_acc_transfer, 'r', label='Transfer Learning Model')
    plt.plot(epochs, val_acc_random, 'b', label='Random Initialization Model')
    plt.xlabel('Epoch')
    plt.ylabel('Validation Accuracy')
    plt.title('Validation Accuracy vs. Epoch')
    plt.legend()
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    # Set number of epochs for training the transfer task models
    epochs = 5
    print('* Data preprocessing')
    train_dataset, validation_dataset, test_dataset = get_transfer_datasets()
    
    histories = {}
    for name, model_class in models.items():
        print(f'* Training {name} for {epochs} epochs')
        model = model_class(input_shape, categories_count)
        model.print_summary()
        history = model.train_model(train_dataset, validation_dataset, epochs)
        histories[name] = history
        print(f'* Evaluating {name}')
        model.evaluate(test_dataset)  # Removed verbose argument here
        print(f'* Confusion Matrix for {name}')
        print(model.get_confusion_matrix(test_dataset))
    
    # Plot validation accuracy for both models
    plot_history_diff(histories['transfer_learning'], histories['random_initialization'])
