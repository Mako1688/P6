from config import BOARD_SIZE, categories, image_size
from tensorflow.keras import models
import numpy as np
import tensorflow as tf

class TicTacToePlayer:
    def get_move(self, board_state):
        raise NotImplementedError()

class UserInputPlayer:
    def get_move(self, board_state):
        inp = input('Enter x y:')
        try:
            x, y = inp.split()
            x, y = int(x), int(y)
            return x, y
        except Exception:
            return None

import random

class RandomPlayer:
    def get_move(self, board_state):
        positions = []
        for i in range(BOARD_SIZE):
            for j in range(BOARD_SIZE):
                if board_state[i][j] is None:
                    positions.append((i, j))
        return random.choice(positions)

from config import image_size, categories
import cv2
import numpy as np
import os
import tensorflow as tf
from tensorflow.keras.models import load_model

class UserWebcamPlayer:
    def __init__(self):
        # Load the trained model once and build the feature extractor
        model_path = 'results/basic_model_15_epochs_timestamp_1740024064.keras'
        if not os.path.exists(model_path):
            raise FileNotFoundError("Trained model not found at " + model_path)
        self.model = load_model(model_path)
        # Choose a feature layer index similar to calibration (e.g., -4 if available)
        if len(self.model.layers) > 5:
            feature_layer_idx = -4
        else:
            feature_layer_idx = -2
        self.feature_model = tf.keras.Model(inputs=self.model.input, outputs=self.model.layers[feature_layer_idx].output)
        self.calibrated = False

    def _process_frame(self, frame):
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        width, height = frame.shape
        size = min(width, height)
        pad = int((width - size) / 2), int((height - size) / 2)
        frame = frame[pad[0]:pad[0] + size, pad[1]:pad[1] + size]
        return frame

    def _access_webcam(self):
        cv2.namedWindow("preview")
        vc = cv2.VideoCapture(0)
        if vc.isOpened():
            rval, frame = vc.read()
            frame = self._process_frame(frame)
        else:
            rval = False
        while rval:
            cv2.imshow("preview", frame)
            rval, frame = vc.read()
            if not rval:
                break
            frame = self._process_frame(frame)
            key = cv2.waitKey(20)
            if key == 13:  # exit on Enter
                break
        vc.release()
        cv2.destroyWindow("preview")
        return frame

    def _print_reference(self, row_or_col):
        print('reference:')
        for i, emotion in enumerate(categories):
            print('{} {} is {}.'.format(row_or_col, i, emotion))
    
    def _get_row_or_col_by_text(self):
        try:
            val = int(input())
            return val
        except Exception as e:
            print('Invalid position')
            return None
    
    def _get_row_or_col(self, is_row):
        try:
            row_or_col = 'row' if is_row else 'col'
            self._print_reference(row_or_col)
            img = self._access_webcam()
            while True:
                emotion = self._get_emotion(img)
                if emotion is None:
                    print('\nPlease try again with a more exaggerated expression.')
                    img = self._access_webcam()
                    continue
                if type(emotion) is not int or emotion not in range(len(categories)):
                    print('Invalid emotion number {}'.format(emotion))
                    return None
                break
            print('Emotion detected as {} ({} {}). Enter \'text\' to use text input instead (0, 1 or 2). Otherwise, press Enter to continue.'.format(categories[emotion], row_or_col, emotion))
            inp = input()
            if inp == 'text':
                return self._get_row_or_col_by_text()
            return emotion
        except Exception as e:
            raise e

    def _get_emotion(self, img):
        """
        Classify facial expression image using calibrated data.
        Now using the preloaded self.feature_model.
        """
        calibration_file = 'user_calibration.npz'
        if not os.path.exists(calibration_file):
            print("\nCalibration data not found. Please run calibration.py first.")
            return None
        
        if not self.calibrated:
            try:
                calibration_data = np.load(calibration_file)
                self.reference_features = {int(k.split('_')[-1]): calibration_data[k] 
                                             for k in calibration_data.files}
                self.calibrated = True
                print("Loaded your custom expression calibration data!")
            except Exception as e:
                print(f"Error loading calibration data: {e}")
                return None
        
        # Process current image
        img_resized = cv2.resize(img, image_size)
        img_rgb = np.stack((img_resized,)*3, axis=-1)
        img_normalized = img_rgb / 255.0
        img_batch = np.expand_dims(img_normalized, axis=0)
        
        # Use the preloaded feature_model to predict features
        current_features = self.feature_model.predict(img_batch, verbose=0)[0]
        if len(current_features.shape) > 1:
            current_features = current_features.flatten()
        
        # Compare with calibrated expressions using cosine similarity
        similarities = {}
        for emotion_idx, ref_features in self.reference_features.items():
            if len(ref_features.shape) > 1:
                ref_features = ref_features.flatten()
            similarity = np.dot(current_features, ref_features) / (
                np.linalg.norm(current_features) * np.linalg.norm(ref_features))
            similarities[emotion_idx] = similarity
        
        min_sim = min(similarities.values())
        max_sim = max(similarities.values())
        range_sim = max_sim - min_sim
        
        enhanced_similarities = {}
        for idx, sim in similarities.items():
            if range_sim > 0.001:
                enhanced_similarities[idx] = ((sim - min_sim) / range_sim) ** 2
            else:
                enhanced_similarities[idx] = sim
        
        emotion_index = max(enhanced_similarities, key=enhanced_similarities.get)
        
        print(f"Raw similarities: {similarities}")
        print(f"Enhanced similarities: {enhanced_similarities}")
        print(f"Final emotion: {categories[emotion_index]}")
        
        return int(emotion_index)

    def get_move(self, board_state):
        row, col = None, None
        while row is None:
            row = self._get_row_or_col(True)
        while col is None:
            col = self._get_row_or_col(False)
        return row, col
