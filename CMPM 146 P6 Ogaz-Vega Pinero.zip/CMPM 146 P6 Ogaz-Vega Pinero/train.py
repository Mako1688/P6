import numpy as np
from preprocess import get_datasets
from models.basic_model import BasicModel
from models.model import Model
from config import image_size
import matplotlib.pyplot as plt
import time
import tensorflow as tf

input_shape = (image_size[0], image_size[1], 3)
categories_count = 3

class StopAtValAccuracy(tf.keras.callbacks.Callback):
    def __init__(self, threshold=0.70):
        super().__init__()
        self.threshold = threshold

    def on_epoch_end(self, epoch, logs=None):
        val_acc = logs.get("val_accuracy")
        if val_acc is not None and val_acc >= self.threshold:
            print(f"\nReached {val_acc*100:.2f}% validation accuracy. Stopping training.")
            self.model.stop_training = True

def plot_history(history):
    acc = history.history['accuracy']
    val_acc = history.history['val_accuracy']
    loss = history.history['loss']
    val_loss = history.history['val_loss']

    epochs = range(1, len(acc) + 1)

    plt.figure(figsize=(24, 6))

    plt.subplot(1, 2, 1)
    plt.plot(epochs, acc, 'b', label='Training Accuracy')
    plt.plot(epochs, val_acc, 'r', label='Validation Accuracy')
    plt.grid(True)
    plt.legend()
    plt.xlabel('Epoch')

    plt.subplot(1, 2, 2)
    plt.plot(epochs, loss, 'b', label='Training Loss')
    plt.plot(epochs, val_loss, 'r', label='Validation Loss')
    plt.grid(True)
    plt.legend()
    plt.xlabel('Epoch')

    plt.show()

if __name__ == "__main__":
    epochs = 20
    print('* Data preprocessing')
    train_dataset, validation_dataset, test_dataset = get_datasets()

    name = 'basic_model'
    print(f'* Training {name} for {epochs} epochs')

    # Instantiate your model
    model = BasicModel(input_shape, categories_count)
    model.print_summary()

    # Create an instance of your custom callback
    stop_callback = StopAtValAccuracy(threshold=0.70)

    # Train the model with the callback
    history = model.model.fit(
        x=train_dataset,
        epochs=epochs,
        verbose="auto",
        validation_data=validation_dataset,
        callbacks=[stop_callback]  # Pass the callback here
    )

    print('* Evaluating {}'.format(name))
    model.model.evaluate(test_dataset, verbose='auto')

    # Print confusion matrix, etc.
    from sklearn.metrics import confusion_matrix
    import numpy as np

    # You already have an in-model confusion matrix, but to do it inline:
    predictions = model.model.predict(test_dataset)
    y_pred = np.argmax(predictions, axis=-1)
    y_true = np.concatenate([np.argmax(y, axis=-1) for x, y in test_dataset])
    cm = confusion_matrix(y_true, y_pred)
    print('* Confusion Matrix for {}'.format(name))
    print(cm)

    # Save the model if it hasn't already stopped
    model_name = f'{name}_{epochs}_epochs_timestamp_{int(time.time())}'
    filename = f'results/{model_name}.keras'
    model.save_model(filename)
    np.save(f'results/{model_name}.npy', history.history)
    print(f'* Model saved as {filename}')

    plot_history(history)
